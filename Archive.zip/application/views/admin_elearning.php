<h4>Data elearning</h4>
<hr>
<p><a class="btn btn-primary" href="<?=base_url()?>admin/add_elearning">Tambah E-learning</a></p>
<?php
	echo $pagination;
	echo $table;
?>