<h4>Data metrik</h4>
<hr>
<p><a class="btn btn-primary" href="<?=base_url()?>admin/add_metric">Tambah metrik</a></p>
<?php
	echo $pagination;
	echo $table;
?>