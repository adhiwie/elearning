<div class="row">
	<div class="span9">
		<?php
			$this->load->view($admin_page);
		?>
	</div>
</div>