<h4>Data user</h4>
<hr>
<p><a class="btn btn-primary" href="<?=base_url()?>admin/add_user">Tambah User</a></p>
<?php
	echo $pagination;
	echo $table;
?>