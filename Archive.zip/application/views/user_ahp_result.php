<center><h4>Hasil Pembobotan dengan AHP</h4></center>
<hr>
<?php
  	echo $table;
?>